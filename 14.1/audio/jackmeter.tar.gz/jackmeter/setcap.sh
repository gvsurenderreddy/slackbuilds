[ -x /sbin/setcap ] && /sbin/setcap cap_ipc_lock,cap_sys_nice=ep usr/bin/jack_meter
