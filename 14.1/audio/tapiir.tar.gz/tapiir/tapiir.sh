#!/bin/sh

exec tapiir --@ARG@ "$@"
