# Create an empty log file if one doesn't already exist
[ ! -e var/log/ices/ices.log ] && touch var/log/ices/ices.log

