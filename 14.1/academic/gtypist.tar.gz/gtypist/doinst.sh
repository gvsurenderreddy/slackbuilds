chroot . /usr/bin/install-info /usr/info/gtypist.info.gz /usr/info/dir 2> /dev/null
