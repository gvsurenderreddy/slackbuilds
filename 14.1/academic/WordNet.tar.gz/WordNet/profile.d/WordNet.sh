#!/bin/sh
WNHOME=/usr
export WNHOME
