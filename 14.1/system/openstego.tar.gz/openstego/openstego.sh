#!/bin/sh
exec java -Xmx512m -jar /usr/share/openstego/openstego.jar "$@"
