chroot . /etc/rc.d/rc.udev reload
