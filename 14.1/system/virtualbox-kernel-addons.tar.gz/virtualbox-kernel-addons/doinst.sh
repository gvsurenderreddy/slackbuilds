chroot . /sbin/depmod -a @KERNEL@
