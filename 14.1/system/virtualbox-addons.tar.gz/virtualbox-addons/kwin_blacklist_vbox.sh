while read line; do
    echo $line
done

echo ""
echo "[Compositing]"
echo "OpenGLIsUnsafe=true"
echo ""
