#!/bin/bash

cd $(dirname $(readlink -f $0))
exec java -jar ./microemulator.jar
