chroot . /sbin/depmod -a

