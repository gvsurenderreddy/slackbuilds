#!/bin/sh
export HEIRLOOM=/opt/heirloom
export MANPATH="$HEIRLOOM/man:$MANPATH"
export PATH="$HEIRLOOM/bin:$PATH"
