chroot . /usr/bin/install-info /usr/info/ratpoison.info.gz /usr/info/dir 2> /dev/null

