[ ! -r etc/wmmonrc ] && cat etc/wmmonrc.sample > etc/wmmonrc

