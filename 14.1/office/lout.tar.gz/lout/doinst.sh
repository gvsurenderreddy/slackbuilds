( /usr/bin/lout -x -s /usr/share/lout/include/init;
  chmod 644 /usr/share/lout/data/*;
  chmod 644 /usr/share/lout/hyph/* )
