#!/bin/sh
export FREEMIND_BASE_DIR="/opt/freemind"
${FREEMIND_BASE_DIR}/freemind.sh ${1+"$@"}
