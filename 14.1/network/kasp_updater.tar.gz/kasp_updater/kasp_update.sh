#!/bin/bash

# Kaspersky Update Mirroring
/usr/sbin/kasp_updater -u -r -s
