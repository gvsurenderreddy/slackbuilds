from distutils.core import setup

import json

setup(name="SocksiPy",
      version="1.0.0",
      description="SOCKS proxy server support module.",
      author="Dan Haim",
      author_email="negativeiq@users.sourceforge.net",
      url = "http://socksipy.sourceforge.net/",
      py_modules=['socks']
     )

