if [ ! -e etc/leafnode/local.groups ]; then
  touch etc/leafnode/local.groups
fi

if [ ! -e etc/leafnode/moderators ]; then
  touch etc/leafnode/moderators
fi

