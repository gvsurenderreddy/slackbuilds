#!/bin/sh
cd /usr/share/games/cpsokoban
./cpsokoban
