#!/bin/sh

cd /usr/share/games/astromenace
./AstroMenace
