#!/bin/sh
cd /usr/share/games/zod-engine
./zod
