#!/bin/sh
cd /usr/share/games/Sokoban
python sokoban.py
