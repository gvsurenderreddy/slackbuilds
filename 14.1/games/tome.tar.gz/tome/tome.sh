#!/bin/sh

GAMES_TOME=/usr/share/games/tome/bin

exec ${GAMES_TOME}/tome "$@"
