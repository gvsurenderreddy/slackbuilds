#!/bin/sh
cd /usr/share/games/boswars
./boswars
