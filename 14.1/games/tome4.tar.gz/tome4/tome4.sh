#!/bin/sh
cd /usr/share/games/tome4
./t-engine
