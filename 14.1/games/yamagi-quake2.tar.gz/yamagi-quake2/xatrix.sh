#!/bin/sh
exec /usr/share/quake2/quake2 +set basedir /usr/share/quake2 +set game xatrix $*
