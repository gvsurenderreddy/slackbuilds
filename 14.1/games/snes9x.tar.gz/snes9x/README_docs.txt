This directory contains the documentation for the original snes9x (the
non-GTK+ version). Not all of the information here applies to snes9x_gtk,
but some of it may still be useful... and the various licenses still
apply.
