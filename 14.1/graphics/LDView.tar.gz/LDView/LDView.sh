#!/bin/sh
cd /usr/share/LDView
/usr/bin/LDView_bin $1
