#!/bin/sh
export PATH="${PATH}:/opt/blender"
