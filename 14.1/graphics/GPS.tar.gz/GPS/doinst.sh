chmod -R 755 /usr/share/gimp/2.0/{brushes,dynamics,gradients,palettes,patterns,splashes,tool-presets,License*,Read*}
chown -R root:root /usr/share/gimp/2.0/{brushes,dynamics,gradients,palettes,patterns,splashes,tool-presets,License*,Read*}
