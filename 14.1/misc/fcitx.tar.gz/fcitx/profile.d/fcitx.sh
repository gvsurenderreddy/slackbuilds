#!/bin/sh

export XMODIFIERS="@im=fcitx"
export XIM=fcitx
export XIM_PROGRAM=fcitx
export GTK_IM_MODULE=fcitx  #=xim
export QT_IM_MODULE=fcitx   #=xim
