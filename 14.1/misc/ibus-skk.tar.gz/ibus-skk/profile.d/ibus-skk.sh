if [ -d /usr/share/ibus-skk ]; then
  export IBUS_SKK_PKGDATADIR=/usr/share/ibus-skk
fi

