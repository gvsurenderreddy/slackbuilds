echo
echo Be sure to read /usr/doc/iscan-firmware-2.8.0.1/README.Slackware
echo for instructions on adding support for loading firmware to your
echo /etc/sane.d/snapscan.conf file.
echo 
