#!/bin/sh

( cd usr/share/fonts/misc; mkfontscale; mkfontdir )
