/usr/bin/vim -c "helptags /usr/share/vim/vimfiles/doc|q"
