#!/bin/sh
export GOROOT=/opt/google/appengine-gosdk/goroot
export PATH="${PATH}:${GOROOT}/bin" 
