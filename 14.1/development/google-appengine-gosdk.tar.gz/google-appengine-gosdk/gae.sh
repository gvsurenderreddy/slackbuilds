#!/bin/csh
export GAEBIN=/opt/google/appengine-gosdk
export PATH=${PATH}:${GAEROOT}
