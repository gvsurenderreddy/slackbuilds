echo ""
echo "put \"(require 'magit)\" in youre emacs startup file to enable magit"
echo ""
