#!/bin/sh
export GROOVY_HOME=@LIBDIR@/groovy
export PATH=${PATH}:${GROOVY_HOME}/bin
