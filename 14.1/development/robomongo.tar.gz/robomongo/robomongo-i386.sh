#!/bin/bash
export LD_LIBRARY_PATH=/usr/lib/robomongo:$LD_LIBRARY_PATH
export QT_PLUGIN_PATH=/usr/lib/robomongo:$QT_PLUGIN_PATH
/usr/bin/robomongo.bin