#!/bin/sh
export PATH=/usr/libexec/icecc/bin:$PATH
