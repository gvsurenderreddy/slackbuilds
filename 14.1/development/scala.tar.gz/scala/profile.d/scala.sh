#!/bin/sh
export SCALA_HOME=@LIBDIR@/scala
export MANPATH="${MANPATH}:${SCALA_HOME}/man"
export PATH="${PATH}:${SCALA_HOME}/bin"
