#!/bin/sh
export GAEROOT=/opt/google/appengine-pysdk
export PATH="${PATH}:${GAEROOT}"
